package com.goon.gooning.data

import com.google.firebase.database.FirebaseDatabase

class UserRepository {

    private val db = FirebaseDatabase.getInstance().reference

    fun getUidByNickname(
        nickname: String,
        onResult: (String?) -> Unit
    ) {
        db.child("nicknames").child(nickname)
            .get()
            .addOnSuccessListener {
                onResult(it.getValue(String::class.java))
            }
            .addOnFailureListener {
                onResult(null)
            }
    }

    fun saveNickname(uid: String, nickname: String) {
        db.child("nicknames").child(nickname).setValue(uid)
        db.child("users").child(uid).child("nickname").setValue(nickname)
    }
}