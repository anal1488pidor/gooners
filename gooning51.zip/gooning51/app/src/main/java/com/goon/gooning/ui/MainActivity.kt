package com.goon.gooning.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.goon.gooning.R

class MainActivity : AppCompatActivity() {

    private val auth by lazy { FirebaseAuth.getInstance() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val user = auth.currentUser

        // ЕСЛИ НЕ ВОШЁЛ — НА ЛОГИН
        if (user == null) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        // ЕСЛИ ВОШЁЛ — ПОКАЗЫВАЕМ ГЛАВНЫЙ ЭКРАН
        setContentView(R.layout.activity_main)
    }
}