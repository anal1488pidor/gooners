package com.goon.gooning.data.model

data class User(
    val uid: String = "",
    val nickname: String = "",
    val dr: Int = 0,
    val fin: Int = 0,
    val inc: Int = 0
)