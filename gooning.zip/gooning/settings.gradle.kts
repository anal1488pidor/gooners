pluginManagement {
    repositories {
        // Порядок важен: сначала google(), потом mavenCentral(), потом gradlePluginPortal
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    // Репозитории управляются из settings — не добавляем их в build.gradle.kts
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "gooners" // или "gooners" — используй то, что у тебя в проекте
include(":app")