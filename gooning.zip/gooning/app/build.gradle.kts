dependencies {
    implementation("androidx.core:core-ktx:1.10.1")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.recyclerview:recyclerview:1.3.1")
    implementation("com.google.android.material:material:1.10.0")

    implementation("com.google.firebase:firebase-auth-ktx:22.2.0")
    implementation("com.google.firebase:firebase-database-ktx:20.2.0")

    implementation("com.github.bumptech.glide:glide:4.16.0")

    // Явно добавляем activity (на всякий случай)
    implementation("androidx.activity:activity-ktx:1.7.2")
}