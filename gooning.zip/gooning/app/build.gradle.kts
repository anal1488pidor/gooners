plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.gms.google-services")
}

android {
    namespace = "com.goon.gooners"
    compileSdk = 33

    defaultConfig {
        applicationId = "com.goon.gooners"
        minSdk = 23
        targetSdk = 33
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    // 🔴 ВАЖНО: ВКЛЮЧАЕМ COMPOSE
    buildFeatures {
        compose = true
    }

    // 🔴 ВАЖНО: ВЕРСИЯ КОМПИЛЯТОРА COMPOSE
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.3"
    }
}

dependencies {

    // 🔹 ANDROID CORE
    implementation("androidx.core:core-ktx:1.10.1")
    implementation("androidx.appcompat:appcompat:1.6.1")

    // 🔹 COMPOSE BOM (ОДНА ВЕРСИЯ НА ВСЁ)
    implementation(platform("androidx.compose:compose-bom:2023.10.01"))

    // 🔹 COMPOSE UI
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")

    // 🔹 АКТИВИТИ ДЛЯ COMPOSE (ВАЖНО: 1.7.2, НЕ 1.8.0)
    implementation("androidx.activity:activity-compose:1.7.2")

    // 🔹 FIREBASE (ЧЕРЕЗ BOM)
    implementation(platform("com.google.firebase:firebase-bom:32.7.0"))
    implementation("com.google.firebase:firebase-auth-ktx")
    implementation("com.google.firebase:firebase-database-ktx")

    // 🔹 GLIDE (если реально используется)
    implementation("com.github.bumptech.glide:glide:4.16.0")

    // 🔹 DEBUG
    debugImplementation("androidx.compose.ui:ui-tooling")
}