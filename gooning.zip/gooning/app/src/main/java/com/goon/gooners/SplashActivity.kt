package com.goon.gooners

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.animation.AlphaAnimation
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.splash_activity)

        val splashImage = findViewById<ImageView>(R.id.splashImage)
        val overlay = findViewById<View>(R.id.overlay)

        val fadeIn = AlphaAnimation(0f, 1f).apply { duration = 1500; fillAfter = true }
        val fadeOverlay = AlphaAnimation(0f, 0.6f).apply { duration = 1500; fillAfter = true }

        splashImage.startAnimation(fadeIn)
        overlay.startAnimation(fadeOverlay)

        splashImage.postDelayed({
            val fadeOut = AlphaAnimation(1f, 0f).apply { duration = 1000; fillAfter = true }
            splashImage.startAnimation(fadeOut)
            overlay.startAnimation(fadeOut)

            splashImage.postDelayed({
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
            }, 1000)
        }, 3000)
    }
}