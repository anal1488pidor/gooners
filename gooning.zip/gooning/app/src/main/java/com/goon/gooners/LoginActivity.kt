package com.goon.gooners

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.*

class LoginActivity : AppCompatActivity() {

    private lateinit var nicknameInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var loginButton: Button
    private lateinit var registerButton: Button

    private val database = FirebaseDatabase.getInstance()
    private val usersRef = database.getReference("users")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        nicknameInput = findViewById(R.id.nicknameInput)
        passwordInput = findViewById(R.id.passwordInput)
        loginButton = findViewById(R.id.loginButton)
        registerButton = findViewById(R.id.registerButton)

        loginButton.setOnClickListener { loginUser() }
        registerButton.setOnClickListener { registerUser() }
    }

    private fun loginUser() {
        val nickname = nicknameInput.text.toString()
        val password = passwordInput.text.toString()
        if (nickname.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Введите ник и пароль", Toast.LENGTH_SHORT).show()
            return
        }

        usersRef.orderByChild("nickname").equalTo(nickname)
            .addListenerForSingleValueEvent(object: ValueEventListener{
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        for (userSnap in snapshot.children) {
                            val storedPassword = userSnap.child("password").getValue(String::class.java)
                            if (storedPassword == password) {
                                val uid = userSnap.key!!
                                startMainActivity(uid)
                                return
                            } else {
                                Toast.makeText(this@LoginActivity, "Неверный пароль", Toast.LENGTH_SHORT).show()
                                return
                            }
                        }
                    } else {
                        Toast.makeText(this@LoginActivity, "Пользователь не найден", Toast.LENGTH_SHORT).show()
                    }
                }
                override fun onCancelled(error: DatabaseError) {}
            })
    }

    private fun registerUser() {
        val nickname = nicknameInput.text.toString()
        val password = passwordInput.text.toString()
        if (nickname.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Введите ник и пароль", Toast.LENGTH_SHORT).show()
            return
        }

        usersRef.orderByChild("nickname").equalTo(nickname)
            .addListenerForSingleValueEvent(object: ValueEventListener{
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        Toast.makeText(this@LoginActivity, "Никнейм уже занят", Toast.LENGTH_SHORT).show()
                    } else {
                        val newUserRef = usersRef.push()
                        val data = mapOf(
                            "nickname" to nickname,
                            "password" to password,
                            "дрочки" to 0,
                            "konчил" to 0,
                            "incidents" to 0,
                            "photoUrl" to ""
                        )
                        newUserRef.setValue(data).addOnSuccessListener {
                            Toast.makeText(this@LoginActivity, "Регистрация успешна", Toast.LENGTH_SHORT).show()
                            startMainActivity(newUserRef.key!!)
                        }
                    }
                }
                override fun onCancelled(error: DatabaseError) {}
            })
    }

    private fun startMainActivity(uid: String) {
        val intent = Intent(this, MainActivity::class.java)
        intent.putExtra("uid", uid)
        startActivity(intent)
        finish()
    }
}