package com.goon.gooners

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*

class LeaderboardActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private val database = FirebaseDatabase.getInstance()
    private val usersRef = database.getReference("users")
    private val userList = mutableListOf<User>()
    private lateinit var adapter: LeaderboardAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_leaderboard)

        recyclerView = findViewById(R.id.leaderboardRecycler)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = LeaderboardAdapter(userList)
        recyclerView.adapter = adapter

        usersRef.orderByChild("дрочки").limitToLast(100)
            .addListenerForSingleValueEvent(object: ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    userList.clear()
                    for (userSnap in snapshot.children) {
                        val nickname = userSnap.child("nickname").getValue(String::class.java) ?: ""
                        val dr = userSnap.child("дрочки").getValue(Int::class.java) ?: 0
                        userList.add(User(nickname, dr))
                    }
                    userList.sortByDescending { it.drCount }
                    adapter.notifyDataSetChanged()
                }
                override fun onCancelled(error: DatabaseError) {}
            })
    }
}

data class User(val nickname: String, val drCount: Int)