package com.goon.gooners

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.*

class MainActivity : AppCompatActivity() {

    private lateinit var doButton: Button
    private lateinit var countText: TextView
    private lateinit var finishText: TextView
    private lateinit var incidentText: TextView
    private lateinit var profileButton: ImageButton
    private lateinit var leaderboardButton: ImageButton

    private lateinit var uid: String
    private val database = FirebaseDatabase.getInstance()
    private lateinit var userRef: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        uid = intent.getStringExtra("uid") ?: return
        userRef = database.getReference("users").child(uid)

        doButton = findViewById(R.id.doButton)
        countText = findViewById(R.id.countText)
        finishText = findViewById(R.id.finishText)
        incidentText = findViewById(R.id.incidentText)
        profileButton = findViewById(R.id.profileButton)
        leaderboardButton = findViewById(R.id.leaderboardButton)

        doButton.setOnClickListener { doAction() }
        profileButton.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java).apply { putExtra("uid", uid) })
        }
        leaderboardButton.setOnClickListener {
            startActivity(Intent(this, LeaderboardActivity::class.java))
        }

        updateCounters()
    }

    private fun doAction() {
        val rand = (1..100).random()
        var message = ""
        userRef.runTransaction(object: Transaction.Handler {
            override fun doTransaction(currentData: MutableData): Transaction.Result {
                val dr = currentData.child("дрочки").getValue(Int::class.java) ?: 0
                val fin = currentData.child("konчил").getValue(Int::class.java) ?: 0
                val inc = currentData.child("incidents").getValue(Int::class.java) ?: 0

                when {
                    rand <= 80 -> {
                        message = "Ты успешно вздрочнул"
                        currentData.child("дрочки").value = dr + 1
                    }
                    rand <= 85 -> {
                        message = "Ты так активно дрочил что порвал уздечку"
                        currentData.child("дрочки").value = dr + 1
                        currentData.child("incidents").value = inc + 1
                    }
                    else -> {
                        message = "Ты подрочил и кончил"
                        currentData.child("дрочки").value = dr + 1
                        currentData.child("konчил").value = fin + 1
                    }
                }
                return Transaction.success(currentData)
            }

            override fun onComplete(error: DatabaseError?, committed: Boolean, currentData: DataSnapshot?) {
                Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show()
                updateCounters()
            }
        })
    }

    private fun updateCounters() {
        userRef.addListenerForSingleValueEvent(object: ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val dr = snapshot.child("дрочки").getValue(Int::class.java) ?: 0
                val fin = snapshot.child("konчил").getValue(Int::class.java) ?: 0
                val inc = snapshot.child("incidents").getValue(Int::class.java) ?: 0

                countText.text = "Дрочек: $dr раз"
                finishText.text = "Кончил: $fin раз"
                incidentText.text = "Инциденты: $inc раз"
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }
}