package com.goon.gooners

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.google.firebase.database.*

class ProfileActivity : AppCompatActivity() {

    private lateinit var uid: String
    private lateinit var photoView: ImageView
    private lateinit var nicknameView: TextView
    private lateinit var drCount: TextView
    private lateinit var finCount: TextView
    private lateinit var incidentCount: TextView
    private val database = FirebaseDatabase.getInstance()
    private lateinit var userRef: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        uid = intent.getStringExtra("uid") ?: return
        userRef = database.getReference("users").child(uid)

        photoView = findViewById(R.id.profilePhoto)
        nicknameView = findViewById(R.id.profileNickname)
        drCount = findViewById(R.id.profileDrCount)
        finCount = findViewById(R.id.profileFinCount)
        incidentCount = findViewById(R.id.profileIncCount)

        userRef.addListenerForSingleValueEvent(object: ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val nickname = snapshot.child("nickname").getValue(String::class.java) ?: "Пользователь"
                val dr = snapshot.child("дрочки").getValue(Int::class.java) ?: 0
                val fin = snapshot.child("konчил").getValue(Int::class.java) ?: 0
                val inc = snapshot.child("incidents").getValue(Int::class.java) ?: 0
                val photoUrl = snapshot.child("photoUrl").getValue(String::class.java) ?: ""

                nicknameView.text = nickname
                drCount.text = "Дрочек: $dr раз"
                finCount.text = "Кончил: $fin раз"
                incidentCount.text = "Инциденты: $inc раз"

                if (photoUrl.isNotEmpty()) Glide.with(this@ProfileActivity).load(photoUrl).into(photoView)
                else photoView.setImageResource(R.drawable.profile)
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }
}