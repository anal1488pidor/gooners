buildscript {
    dependencies {
        classpath("com.google.gms:google-services:4.4.0")
    }
}

plugins {
    id("com.android.application") version "8.1.0" apply false
    id("org.jetbrains.kotlin.android") version "1.9.10" apply false
}

allprojects {
    configurations.all {
        resolutionStrategy {
            force("androidx.activity:activity:1.7.2")
            force("androidx.activity:activity-ktx:1.7.2")
        }
    }
}
