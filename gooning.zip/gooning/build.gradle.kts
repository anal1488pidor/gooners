// Корневой build.gradle.kts

buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        // Android Gradle Plugin
        classpath("com.android.tools.build:gradle:8.1.0")

        // Kotlin Gradle Plugin
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.10")

        // Google Services (Firebase)
        classpath("com.google.gms:google-services:4.4.0")
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

// 🔴 КЛЮЧЕВОЙ ФИКС ДЛЯ ОШИБКИ androidx.activity:1.8.0
subprojects {
    configurations.all {
        resolutionStrategy {
            force("androidx.activity:activity:1.7.2")
            force("androidx.activity:activity-ktx:1.7.2")
        }
    }
}