// Корневой build.gradle.kts — только плагины и универсальные настройки

plugins {
    // AGP и Kotlin подключены здесь с apply false (модули сами применяют их)
    id("com.android.application") version "8.1.0" apply false
    id("org.jetbrains.kotlin.android") version "1.9.10" apply false

    // Google Services плагин подключаем здесь (apply false) — он будет использоваться в модуле app
    id("com.google.gms.google-services") version "4.4.0" apply false
}

// Принудительная фиксация проблемных зависимостей (чтобы не подтягивалась activity:1.8.0)
subprojects {
    configurations.all {
        resolutionStrategy {
            // Зафиксируем activity на 1.7.2 (совместима с compileSdk=33)
            force("androidx.activity:activity:1.7.2")
            force("androidx.activity:activity-ktx:1.7.2")
        }
    }
}

// Регистрация clean-задания
tasks.register<Delete>("clean") {
    delete(rootProject.buildDir)
}