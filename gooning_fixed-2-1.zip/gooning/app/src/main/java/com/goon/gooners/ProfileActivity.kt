package com.goon.gooners

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.google.firebase.database.FirebaseDatabase

class ProfileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val uid = intent.getStringExtra("uid") ?: return
        val ref = FirebaseDatabase.getInstance().getReference("users").child(uid)

        ref.get().addOnSuccessListener {
            findViewById<TextView>(R.id.profileNickname).text =
                it.child("nickname").value?.toString() ?: "User"

            findViewById<TextView>(R.id.profileDrCount).text =
                "Дрочек: ${it.child("дрочки").value ?: 0}"

            findViewById<TextView>(R.id.profileFinCount).text =
                "Кончил: ${it.child("konчил").value ?: 0}"

            findViewById<TextView>(R.id.profileIncCount).text =
                "Инциденты: ${it.child("incidents").value ?: 0}"

            val img = it.child("photoUrl").value?.toString()
            if (!img.isNullOrEmpty())
                Glide.with(this).load(img).into(findViewById(R.id.profilePhoto))
        }
    }
}
