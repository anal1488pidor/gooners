package com.goon.gooners

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.*

class MainActivity : AppCompatActivity() {

    private lateinit var uid: String
    private lateinit var userRef: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        uid = intent.getStringExtra("uid") ?: run {
            Toast.makeText(this, "UID not found", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        userRef = FirebaseDatabase.getInstance().getReference("users").child(uid)

        findViewById<Button>(R.id.doButton).setOnClickListener { doAction() }
        findViewById<ImageButton>(R.id.profileButton).setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java).putExtra("uid", uid))
        }
        findViewById<ImageButton>(R.id.leaderboardButton).setOnClickListener {
            startActivity(Intent(this, LeaderboardActivity::class.java))
        }

        updateCounters()
    }

    private fun doAction() {
        val rand = (1..100).random()

        userRef.runTransaction(object : Transaction.Handler {
            override fun doTransaction(data: MutableData): Transaction.Result {
                val dr = data.child("дрочки").getValue(Int::class.java) ?: 0
                val fin = data.child("konчил").getValue(Int::class.java) ?: 0
                val inc = data.child("incidents").getValue(Int::class.java) ?: 0

                val msg = when {
                    rand <= 80 -> {
                        data.child("дрочки").value = dr + 1
                        "Успешно"
                    }
                    rand <= 85 -> {
                        data.child("дрочки").value = dr + 1
                        data.child("incidents").value = inc + 1
                        "Инцидент"
                    }
                    else -> {
                        data.child("дрочки").value = dr + 1
                        data.child("konчил").value = fin + 1
                        "Финиш"
                    }
                }
                data.child("_msg").value = msg
                return Transaction.success(data)
            }

            override fun onComplete(e: DatabaseError?, b: Boolean, s: DataSnapshot?) {
                Toast.makeText(this@MainActivity, s?.child("_msg")?.value.toString(), Toast.LENGTH_SHORT).show()
                updateCounters()
            }
        })
    }

    private fun updateCounters() {
        userRef.get().addOnSuccessListener {
            findViewById<TextView>(R.id.countText).text = "Дрочек: ${it.child("дрочки").getValue(Int::class.java) ?: 0}"
            findViewById<TextView>(R.id.finishText).text = "Кончил: ${it.child("konчил").getValue(Int::class.java) ?: 0}"
            findViewById<TextView>(R.id.incidentText).text = "Инциденты: ${it.child("incidents").getValue(Int::class.java) ?: 0}"
        }
    }
}
