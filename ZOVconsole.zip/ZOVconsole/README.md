ZOVconsole - customizable Android IME (sample project)
-----------------------------------------------------
This archive contains a minimal Android project for an input method (keyboard) named "ZOVconsole".
It includes:
  - app module with Kotlin sources for KeyboardService, KeyboardView and basic JSON-based layout support
  - assets/example layout JSON
  - minimal Gradle build files (you may need to run `./gradlew wrapper` locally or use GitHub Actions)
  - example GitHub Actions workflow in .github/workflows/android.yml

Notes:
  - The Gradle wrapper JAR (gradle-wrapper.jar) is not included. On a developer machine, run:
        ./gradlew wrapper
    to generate the wrapper, or install Gradle and build normally.
  - This project is intended as a starting point. Customize the settings UI, themes and features as needed.
