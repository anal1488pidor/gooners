package com.zov.zovconsole.ime

data class KeyModel(
    val label: String,
    val action: String,
    val value: String? = null
)
