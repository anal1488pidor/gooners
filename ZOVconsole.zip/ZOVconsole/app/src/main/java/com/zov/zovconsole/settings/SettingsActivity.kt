package com.zov.zovconsole.settings

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.zov.zovconsole.R

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Simple placeholder - developer should implement UI to edit JSON/layouts/themes
        setContentView(android.R.layout.simple_list_item_1)
    }
}
