package com.zov.zovconsole.ime

import android.content.Context
import android.graphics.Typeface
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream

class KeyboardView(context: Context) : LinearLayout(context) {
    var onKeyPress: ((KeyModel) -> Unit)? = null

    init {
        orientation = VERTICAL
        buildFromAsset("layout_default.json")
    }

    private fun readAsset(name: String): String {
        val am = context.assets
        val stream: InputStream = am.open(name)
        return stream.bufferedReader().use { it.readText() }
    }

    fun buildFromAsset(assetName: String) {
        removeAllViews()
        val json = readAsset(assetName)
        val obj = JSONObject(json)
        val rows = obj.getJSONArray("rows")

        for (i in 0 until rows.length()) {
            val row = rows.getJSONArray(i)
            val rowLayout = LinearLayout(context)
            rowLayout.orientation = HORIZONTAL
            rowLayout.layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)

            val grid = GridLayout(context)
            grid.columnCount = row.length()
            grid.layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
            grid.alignmentMode = GridLayout.ALIGN_MARGINS

            for (j in 0 until row.length()) {
                val k = row.getJSONObject(j)
                val label = k.getString("label")
                val action = k.getString("action")
                val value = if (k.has("value")) k.getString("value") else null

                val btn = Button(context)
                btn.text = label
                btn.typeface = Typeface.MONOSPACE
                btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                btn.layoutParams = GridLayout.LayoutParams().apply {
                    width = 0
                    height = LayoutParams.WRAP_CONTENT
                    columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                }
                btn.setOnClickListener {
                    val key = KeyModel(label, action, value)
                    onKeyPress?.invoke(key)
                }
                grid.addView(btn)
            }

            addView(grid)
        }
    }
}
