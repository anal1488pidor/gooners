package com.zov.zovconsole.ime

import android.inputmethodservice.InputMethodService
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.InputConnection

class KeyboardService : InputMethodService() {
    private lateinit var keyboardView: KeyboardView

    override fun onCreateInputView(): View {
        keyboardView = KeyboardView(this)
        keyboardView.onKeyPress = { key ->
            val ic: InputConnection = currentInputConnection ?: return@KeyboardView
            when (key.action) {
                "text" -> ic.commitText(key.value ?: "", 1)
                "delete" -> ic.deleteSurroundingText(1, 0)
                "enter" -> {
                    ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
                    ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
                }
                "macro" -> ic.commitText(key.value ?: "", 1)
                else -> ic.commitText(key.value ?: "", 1)
            }
        }
        return keyboardView
    }
}
