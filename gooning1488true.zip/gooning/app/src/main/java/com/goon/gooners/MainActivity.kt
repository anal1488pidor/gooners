package com.goon.gooners

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class MainActivity : AppCompatActivity() {

    private lateinit var doButton: Button
    private lateinit var countText: TextView
    private lateinit var finishText: TextView
    private lateinit var incidentText: TextView
    private lateinit var profileButton: ImageButton
    private lateinit var leaderboardButton: ImageButton

    private lateinit var uid: String
    private val auth = FirebaseAuth.getInstance()
    private val database = FirebaseDatabase.getInstance()
    private lateinit var userRef: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 🔥 ГЛАВНОЕ ИСПРАВЛЕНИЕ
        if (auth.currentUser == null) {
            auth.signInAnonymously().addOnSuccessListener {
                initUser(it.user!!.uid)
            }.addOnFailureListener {
                Toast.makeText(this, "Ошибка авторизации", Toast.LENGTH_LONG).show()
                finish()
            }
        } else {
            initUser(auth.currentUser!!.uid)
        }
    }

    private fun initUser(userUid: String) {
        uid = userUid
        userRef = database.getReference("users").child(uid)

        doButton = findViewById(R.id.doButton)
        countText = findViewById(R.id.countText)
        finishText = findViewById(R.id.finishText)
        incidentText = findViewById(R.id.incidentText)
        profileButton = findViewById(R.id.profileButton)
        leaderboardButton = findViewById(R.id.leaderboardButton)

        doButton.setOnClickListener { doAction() }

        profileButton.setOnClickListener {
            startActivity(
                Intent(this, ProfileActivity::class.java)
                    .putExtra("uid", uid)
            )
        }

        leaderboardButton.setOnClickListener {
            startActivity(Intent(this, LeaderboardActivity::class.java))
        }

        createUserIfNotExists()
        updateCounters()
    }

    private fun createUserIfNotExists() {
        userRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (!snapshot.exists()) {
                    userRef.setValue(
                        mapOf(
                            "nickname" to "Пользователь",
                            "дрочки" to 0,
                            "konчил" to 0,
                            "incidents" to 0
                        )
                    )
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun doAction() {
        val rand = (1..100).random()
        var message = ""

        userRef.runTransaction(object : Transaction.Handler {
            override fun doTransaction(data: MutableData): Transaction.Result {
                val dr = data.child("дрочки").getValue(Int::class.java) ?: 0
                val fin = data.child("konчил").getValue(Int::class.java) ?: 0
                val inc = data.child("incidents").getValue(Int::class.java) ?: 0

                when {
                    rand <= 80 -> {
                        message = "Ты успешно вздрочнул"
                        data.child("дрочки").value = dr + 1
                    }
                    rand <= 85 -> {
                        message = "Ты порвал уздечку"
                        data.child("дрочки").value = dr + 1
                        data.child("incidents").value = inc + 1
                    }
                    else -> {
                        message = "Ты подрочил и кончил"
                        data.child("дрочки").value = dr + 1
                        data.child("konчил").value = fin + 1
                    }
                }
                return Transaction.success(data)
            }

            override fun onComplete(
                error: DatabaseError?,
                committed: Boolean,
                snapshot: DataSnapshot?
            ) {
                Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show()
                updateCounters()
            }
        })
    }

    private fun updateCounters() {
        userRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val dr = snapshot.child("дрочки").getValue(Int::class.java) ?: 0
                val fin = snapshot.child("konчил").getValue(Int::class.java) ?: 0
                val inc = snapshot.child("incidents").getValue(Int::class.java) ?: 0

                countText.text = "Дрочек: $dr"
                finishText.text = "Кончил: $fin"
                incidentText.text = "Инциденты: $inc"
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }
}