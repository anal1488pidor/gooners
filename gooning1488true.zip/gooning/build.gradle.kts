// Корневой build.gradle.kts — плагины подключаем с apply false, и форсим проблемные версии

plugins {
    id("com.android.application") version "8.1.0" apply false
    id("org.jetbrains.kotlin.android") version "1.9.10" apply false
    id("com.google.gms.google-services") version "4.4.0" apply false
}

/*
  Принудительная фиксация проблемных библиотек, чтобы не подтянулось
  поведения, требующее compileSdk 34 (например emoji2:1.4.0 или activity:1.8.x).
*/
subprojects {
    configurations.all {
        resolutionStrategy {
            force(
                "androidx.emoji2:emoji2:1.3.0",
                "androidx.emoji2:emoji2-views-helper:1.3.0",
                "androidx.activity:activity:1.7.2",
                "androidx.activity:activity-ktx:1.7.2",
                "androidx.activity:activity-compose:1.7.2"
            )
        }
    }
}

tasks.register<Delete>("clean") {
    delete(rootProject.buildDir)
}
