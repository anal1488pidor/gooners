package com.goon.keyboard.storage

data class LayoutModel(
    var name: String,
    var keys: MutableList<String>
)
