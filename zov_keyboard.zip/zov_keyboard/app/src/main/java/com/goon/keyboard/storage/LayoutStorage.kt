package com.goon.keyboard.storage

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class LayoutStorage(private val ctx: Context) {

    private val file = File(ctx.filesDir, "layouts.json")

    private fun defaultLayouts(): MutableList<LayoutModel> {
        val default = MutableList(40) { "" }
        // fill some default keys similar to typical russian qwerty for convenience (partial)
        val sample = listOf("1","2","3","4","5","6","7","8","9","0",
            "й","ц","у","к","е","н","г","ш","щ","з",
            "ф","ы","в","а","п","р","о","л","д","ж",
            "SHIFT","я","ч","с","м","и","т","ь","б","BACK")
        val keys = MutableList(40) { index ->
            if (index < sample.size) sample[index] else ""
        }
        val layouts = mutableListOf(LayoutModel("Default", keys))
        return layouts
    }

    fun loadAll(): MutableList<LayoutModel> {
        if (!file.exists()) {
            val def = defaultLayouts()
            saveAll(def, 0)
            return def
        }
        val txt = file.readText()
        val root = JSONObject(txt)
        val arr = root.optJSONArray("layouts") ?: JSONArray()
        val list = mutableListOf<LayoutModel>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            val name = obj.optString("name", "layout$i")
            val keysJson = obj.optJSONArray("keys") ?: JSONArray()
            val keys = MutableList(keysJson.length()) { idx -> keysJson.optString(idx, "") }
            list.add(LayoutModel(name, keys))
        }
        return list
    }

    fun saveAll(list: List<LayoutModel>, activeIndex: Int) {
        val root = JSONObject()
        val arr = JSONArray()
        list.forEach { lay ->
            val obj = JSONObject()
            obj.put("name", lay.name)
            val keysArr = JSONArray()
            lay.keys.forEach { keysArr.put(it) }
            obj.put("keys", keysArr)
            arr.put(obj)
        }
        root.put("layouts", arr)
        root.put("active", activeIndex)
        file.writeText(root.toString())
    }

    fun loadActiveIndex(): Int {
        if (!file.exists()) return 0
        val txt = file.readText()
        val root = JSONObject(txt)
        return root.optInt("active", 0)
    }

    fun saveWithActive(list: List<LayoutModel>, activeIndex: Int) {
        saveAll(list, activeIndex)
    }

    // helpers used by UI
    fun addLayout(name: String, size: Int = 40): Int {
        val all = loadAll()
        val keys = MutableList(size) { "" }
        all.add(LayoutModel(name, keys))
        saveAll(all, all.size - 1)
        return all.size - 1
    }

    fun deleteLayout(index: Int) {
        val all = loadAll()
        if (index in all.indices) {
            all.removeAt(index)
            val newActive = if (index == 0) 0 else (index - 1).coerceAtMost(all.size - 1)
            saveAll(all, newActive)
        }
    }

    fun renameLayout(index: Int, newName: String) {
        val all = loadAll()
        if (index in all.indices) {
            all[index].name = newName
            saveAll(all, loadActiveIndex())
        }
    }

    fun setKey(indexLayout: Int, pos: Int, value: String) {
        val all = loadAll()
        if (indexLayout in all.indices) {
            val keys = all[indexLayout].keys
            if (pos in keys.indices) {
                keys[pos] = value
                saveAll(all, loadActiveIndex())
            }
        }
    }

    fun getLayout(index: Int): LayoutModel {
        val all = loadAll()
        return if (index in all.indices) all[index] else all[0]
    }

    fun setActive(index: Int) {
        val all = loadAll()
        val idx = index.coerceIn(0, all.size - 1)
        saveAll(all, idx)
    }

    fun cycleNext(): Int {
        val all = loadAll()
        val cur = loadActiveIndex()
        val next = if (all.isEmpty()) 0 else (cur + 1) % all.size
        saveAll(all, next)
        return next
    }
}
