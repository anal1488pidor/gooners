package com.goon.keyboard.ime

import android.inputmethodservice.InputMethodService
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import com.goon.keyboard.storage.LayoutStorage

class KeyboardService : InputMethodService() {

    private val storage by lazy { LayoutStorage(this) }

    override fun onCreateInputView(): View {
        return buildKeyboardView()
    }

    private fun buildKeyboardView(): View {
        val layout = storage.getLayout(storage.loadActiveIndex())
        val keys = layout.keys
        val grid = GridLayout(this)
        grid.columnCount = 10
        grid.rowCount = (keys.size + 9) / 10
        grid.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        keys.forEachIndexed { index, symbol ->
            val btn = Button(this)
            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = ViewGroup.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(6,6,6,6)
            }
            btn.layoutParams = params
            btn.isAllCaps = false
            btn.textSize = 18f
            btn.gravity = Gravity.CENTER
            btn.text = if (symbol.isEmpty()) "" else symbol

            btn.setOnClickListener {
                when(symbol) {
                    "SHIFT" -> {
                        // simple behavior: insert nothing (could implement shift)
                    }
                    "BACK", "BACKSPACE" -> currentInputConnection.deleteSurroundingText(1,0)
                    "SPACE" -> currentInputConnection.commitText(" ",1)
                    "ENTER", "\n" -> currentInputConnection.commitText("\n",1)
                    "LANG" -> {
                        storage.cycleNext()
                        // rebuild keyboard view to reflect new active layout
                        val newView = buildKeyboardView()
                        // setInputView is protected; use provided method to update input view
                        // replace current input view
                        this.inputView?.let {
                            // detach and set new view
                            (it.parent as? ViewGroup)?.removeView(it)
                        }
                        setInputView(newView)
                    }
                    else -> {
                        if (symbol.isNotEmpty()) currentInputConnection.commitText(symbol,1)
                    }
                }
            }
            grid.addView(btn)
        }

        return grid
    }
}
