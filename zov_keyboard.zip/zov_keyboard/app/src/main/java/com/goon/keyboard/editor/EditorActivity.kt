package com.goon.keyboard.editor

import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.goon.keyboard.R
import com.goon.keyboard.storage.LayoutModel
import com.goon.keyboard.storage.LayoutStorage

class EditorActivity : AppCompatActivity() {

    private lateinit var adapter: KeyAdapter
    private val storage by lazy { LayoutStorage(this) }
    private lateinit var spinner: Spinner
    private var layouts: MutableList<LayoutModel> = mutableListOf()
    private var activeIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editor)

        spinner = findViewById(R.id.layoutSpinner)
        val btnAdd = findViewById<ImageButton>(R.id.btnAdd)
        val btnRename = findViewById<ImageButton>(R.id.btnRename)
        val btnDelete = findViewById<ImageButton>(R.id.btnDelete)
        val recycler = findViewById<RecyclerView>(R.id.recycler)
        recycler.layoutManager = GridLayoutManager(this, 10)

        loadLayouts()

        adapter = KeyAdapter(layouts[activeIndex].keys) { pos ->
            openInputDialog(pos)
        }
        recycler.adapter = adapter

        setupSpinner()

        btnAdd.setOnClickListener { addLayoutDialog() }
        btnRename.setOnClickListener { renameLayoutDialog() }
        btnDelete.setOnClickListener { deleteLayoutDialog() }
    }

    private fun loadLayouts() {
        layouts = storage.loadAll()
        activeIndex = storage.loadActiveIndex().coerceIn(0, layouts.size -1)
    }

    private fun setupSpinner() {
        val names = layouts.map { it.name }
        val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, names)
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = ad
        spinner.setSelection(activeIndex)
        spinner.setOnItemSelectedListener(object: android.widget.AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: android.widget.AdapterView<*>, view: View?, position: Int, id: Long) {
                if (position != activeIndex) {
                    activeIndex = position
                    storage.setActive(activeIndex)
                    adapter.keys.clear()
                    adapter.keys.addAll(layouts[activeIndex].keys)
                    adapter.notifyDataSetChanged()
                }
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>) {}
        })
    }

    private fun refreshLayoutsAndSpinner() {
        loadLayouts()
        setupSpinner()
    }

    private fun addLayoutDialog() {
        val input = EditText(this)
        input.hint = "Имя раскладки"
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.add_layout))
            .setView(input)
            .setPositiveButton("Создать") { _, _ ->
                val name = input.text.toString().ifEmpty { "custom" }
                val idx = storage.addLayout(name, 40)
                // reload
                loadLayouts()
                activeIndex = idx
                setupSpinner()
                adapter.keys.clear()
                adapter.keys.addAll(layouts[activeIndex].keys)
                adapter.notifyDataSetChanged()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun renameLayoutDialog() {
        val input = EditText(this)
        input.hint = "Новое имя"
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.rename_layout))
            .setView(input)
            .setPositiveButton("ОК") { _, _ ->
                val newName = input.text.toString().ifEmpty { layouts[activeIndex].name }
                storage.renameLayout(activeIndex, newName)
                loadLayouts()
                setupSpinner()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun deleteLayoutDialog() {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.delete_layout))
            .setMessage("Удалить раскладку "${layouts[activeIndex].name}"?")
            .setPositiveButton("Удалить") { _, _ ->
                storage.deleteLayout(activeIndex)
                loadLayouts()
                activeIndex = storage.loadActiveIndex()
                adapter.keys.clear()
                adapter.keys.addAll(layouts[activeIndex].keys)
                adapter.notifyDataSetChanged()
                setupSpinner()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun openInputDialog(position: Int) {
        val input = EditText(this)
        input.textSize = 24f

        AlertDialog.Builder(this)
            .setTitle(getString(R.string.enter_symbol_title))
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                val value = input.text.toString()
                if (value.isNotEmpty()) {
                    adapter.keys[position] = value
                    adapter.notifyItemChanged(position)
                    storage.setKey(activeIndex, position, value)
                }
            }
            .setNegativeButton("Отмена", null)
            .show()

        input.post {
            input.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
        }
    }
}
