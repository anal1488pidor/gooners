zov keyboard - Android IME with editable layouts

How to use:
1. Open project in JStudio on your phone (or Android Studio on PC).
2. Edit code, commit and push to GitHub main branch.
3. GitHub Actions will run the workflow and (if Gradle wrapper present) build an APK.

Important notes:
- This ZIP contains the full source code, resources and a GitHub Actions workflow.
- This environment cannot compile an APK here. You need to either add Gradle wrapper files (gradlew, gradle/wrapper/*)
  or run Gradle on a machine that has Gradle installed.
- If you use GitHub Actions, include Gradle wrapper in repo or change the workflow to install Gradle.
