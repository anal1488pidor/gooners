package com.goon.gooning.ui

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.goon.gooning.R
import com.goon.gooning.data.PasswordHasher
import com.goon.gooning.data.UserRepository
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import java.util.UUID

class RegisterActivity : AppCompatActivity() {

    private lateinit var nicknameInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var registerBtn: Button

    private val auth = FirebaseAuth.getInstance()
    private val repo = UserRepository()
    private val db = FirebaseDatabase.getInstance().reference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        nicknameInput = findViewById(R.id.nicknameInput)
        passwordInput = findViewById(R.id.passwordInput)
        registerBtn = findViewById(R.id.registerBtn)

        registerBtn.setOnClickListener {
            register()
        }
    }

    private fun register() {
        val nickname = nicknameInput.text.toString().trim()
        val password = passwordInput.text.toString().trim()

        if (nickname.length < 3 || password.length < 4) {
            toast("Слишком короткие данные")
            return
        }

        // Проверяем, занят ли ник
        repo.getUidByNickname(nickname) { existingUid ->
            if (existingUid != null) {
                toast("Ник уже занят")
                return@getUidByNickname
            }

            createUser(nickname, password)
        }
    }

    private fun createUser(nickname: String, password: String) {
        val publicId = UUID.randomUUID().toString().substring(0, 8)
        val hashedPassword = PasswordHasher.hash(password)

        auth.createUserWithEmailAndPassword(
            "$publicId@gooning.fake",
            hashedPassword
        ).addOnSuccessListener {

            val uid = it.user!!.uid

            // сохраняем профиль
            val userData = mapOf(
                "nickname" to nickname,
                "publicId" to publicId,
                "дрочки" to 0,
                "konчил" to 0,
                "incidents" to 0
            )

            db.child("users").child(uid).setValue(userData)
            repo.saveNickname(uid, nickname)

            startActivity(Intent(this, MainActivity::class.java))
            finish()

        }.addOnFailureListener {
            toast("Ошибка регистрации")
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}