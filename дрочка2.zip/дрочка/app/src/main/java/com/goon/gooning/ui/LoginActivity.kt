package com.goon.gooning.ui

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.goon.gooning.R
import com.goon.gooning.data.SessionManager
import com.goon.gooning.data.UserRepository
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {

    private lateinit var nicknameInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var loginBtn: Button

    private val auth = FirebaseAuth.getInstance()
    private val repo = UserRepository()
    private lateinit var session: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        session = SessionManager(this)

        // Если уже вошёл — сразу в Main
        if (session.isLoggedIn()) {
            openMain()
            return
        }

        nicknameInput = findViewById(R.id.nicknameInput)
        passwordInput = findViewById(R.id.passwordInput)
        loginBtn = findViewById(R.id.loginBtn)

        loginBtn.setOnClickListener {
            login()
        }
    }

    private fun login() {
        val nickname = nicknameInput.text.toString().trim()
        val password = passwordInput.text.toString().trim()

        if (nickname.isEmpty() || password.isEmpty()) {
            toast("Заполни все поля")
            return
        }

        repo.getUidByNickname(nickname) { uid ->
            if (uid == null) {
                toast("Пользователь не найден")
                return@getUidByNickname
            }

            // Логинимся через Firebase Auth
            auth.signInWithEmailAndPassword(
                "$uid@gooning.fake", // технический email
                password
            ).addOnSuccessListener {
                openMain()
            }.addOnFailureListener {
                toast("Неверный пароль")
            }
        }
    }

    private fun openMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}