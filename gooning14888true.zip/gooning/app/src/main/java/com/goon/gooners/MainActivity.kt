package com.goon.gooners

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class MainActivity : AppCompatActivity() {

    private lateinit var uid: String
    private lateinit var userRef: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        uid = intent.getStringExtra("uid")
            ?: FirebaseAuth.getInstance().currentUser?.uid
            ?: run {
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
                return
            }

        userRef = FirebaseDatabase.getInstance().reference.child("users").child(uid)

        val doBtn = findViewById<Button>(R.id.doButton)
        val drText = findViewById<TextView>(R.id.countText)
        val finText = findViewById<TextView>(R.id.finishText)
        val incText = findViewById<TextView>(R.id.incidentText)
        val sensor = findViewById<TextView>(R.id.sensorText)

        findViewById<ImageButton>(R.id.profileButton).setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java).putExtra("uid", uid))
        }

        findViewById<ImageButton>(R.id.leaderboardButton).setOnClickListener {
            startActivity(Intent(this, LeaderboardActivity::class.java))
        }

        doBtn.setOnClickListener {
            val rand = (1..100).random()
            var sensorMsg = ""

            userRef.runTransaction(object : Transaction.Handler {
                override fun doTransaction(data: MutableData): Transaction.Result {
                    val d = data.child("дрочки").getValue(Int::class.java) ?: 0
                    val f = data.child("konчил").getValue(Int::class.java) ?: 0
                    val i = data.child("incidents").getValue(Int::class.java) ?: 0

                    when {
                        rand <= 80 -> data.child("дрочки").value = d + 1
                        rand <= 90 -> {
                            data.child("дрочки").value = d + 1
                            data.child("incidents").value = i + 1
                            sensorMsg = "Больно, но приятно"
                        }
                        else -> {
                            data.child("дрочки").value = d + 1
                            data.child("konчил").value = f + 1
                        }
                    }
                    data.child("sensor").value = sensorMsg
                    return Transaction.success(data)
                }

                override fun onComplete(e: DatabaseError?, c: Boolean, s: DataSnapshot?) {
                    update(drText, finText, incText, sensor)
                }
            })
        }

        update(drText, finText, incText, sensor)
    }

    private fun update(a: TextView, b: TextView, c: TextView, s: TextView) {
        userRef.get().addOnSuccessListener {
            a.text = "Дрочек: ${it.child("дрочки").value ?: 0}"
            b.text = "Кончил: ${it.child("konчил").value ?: 0}"
            c.text = "Инциденты: ${it.child("incidents").value ?: 0}"
            s.text = it.child("sensor").value?.toString() ?: ""
        }
    }
}