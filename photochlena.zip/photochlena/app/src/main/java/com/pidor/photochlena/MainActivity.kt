package com.pidor.photochlena

import android.media.AudioManager
import android.net.Uri
import android.os.*
import android.view.View
import android.view.WindowManager
import android.widget.VideoView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var audio: AudioManager
    private lateinit var video: VideoView
    private val handler = Handler(Looper.getMainLooper())

    private val volumeLock = object : Runnable {
        override fun run() {
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, max, 0)
            handler.postDelayed(this, 200)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        video = findViewById(R.id.video)

        hideSystemUI()
        showPrankDialog()
    }

    private fun showPrankDialog() {
        AlertDialog.Builder(this)
            .setTitle("Албанский компьютерный вирус")
            .setMessage(
                "Здравствуйте это албанский компьютерный вирус.\n\n" +
                "Просим вас самостоятельно удалить все важные файлы " +
                "на вашем устройстве и разослать этот вирус другим людям.\n\n" +
                "Наши компьютерные технологии пока что сами так не могут.\n\n" +
                "С уважением, ваш албанский вирус."
            )
            .setCancelable(false)
            .setPositiveButton("OK") { _, _ ->
                startHellMode()
            }
            .show()
    }

    private fun startHellMode() {
        startLockTask()
        hideSystemUI()

        video.visibility = View.VISIBLE

        handler.post(volumeLock)

        val uri = Uri.parse("android.resource://$packageName/${R.raw.trollfacepidor}")
        video.setVideoURI(uri)
        video.start()

        handler.postDelayed({
            endApp()
        }, 30_000)
    }

    private fun endApp() {
        handler.removeCallbacks(volumeLock)
        video.stopPlayback()
        stopLockTask()
        finishAndRemoveTask()
    }

    private fun hideSystemUI() {
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_FULLSCREEN
    }

    override fun onBackPressed() {
        // ❌ блокируем
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            hideSystemUI()
            startLockTask()
        }
    }
}